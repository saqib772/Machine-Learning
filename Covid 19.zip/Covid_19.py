import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import plotly.express as xp

# from sklearn.metrics import r2_score
plt.style.use("ggplot")

data1=pd.read_csv("CONVENIENT_global_confirmed_cases.csv")
data2=pd.read_csv("CONVENIENT_global_deaths.csv")

# data Preparation 

#Now I am preparing for Comaprison between country and cases
world=pd.DataFrame({"Country":[],"cases":[]})

# Populating the "Country" column with the column names (countries) from the confirmed cases data
world["Country"]=data1.iloc[:,1:].columns 

# Calculating the total number of confirmed cases for each country and storing the results in the "cases" column

cases=[]
for i in world["Country"]:
    cases.append(pd.to_numeric(data1[i][1:]).sum())

world["cases"]=cases

# Cleaning up the country names by removing any dots or parentheses

country_list=list(world["Country"].values)
index=0
# remove the . and ( from country name 
for i in country_list:
    count=0
    for j in i:
        if j==".":
            i=i[:count]
            country_list[index]=i
        elif j=="(":
            i=i[:count-1]
            country_list[index]=i
        else:
            count=count+1
    
    index+=1

world["Country"]=country_list 

# Reading in a CSV file called "continents2.csv" and storing it in a DataFrame called continent

continent=pd.read_csv("continents2.csv")

# Converting the "name" column in the continent DataFrame to uppercase

continent["name"]=continent["name"].str.upper()

#DATA VISUALIZATION

# Start by Looking for world wide Spread of COvid-19
world["Cases Range"]=pd.cut(world["cases"],[-150000,50000,200000,800000,1500000,15000000],labels=["U50K","50Kto200K","200Kto800K","800Kto1.5M","1.5M+"])


# Creating a new column in the world DataFrame called "Alpha3" and storing the "alpha-3" value for each country from the continent DataFrame

alpha=[]

for i in world["Country"].str.upper().values:
    if i == "BRUNEI":
        i="BRUNEI DARUSSALAM"
    elif  i=="US":
        i="UNITED STATES" 

    if len(continent[continent["name"]==i]["alpha-3"].values)==0:
        alpha.append(np.nan)
    else:
        alpha.append(continent[continent["name"]==i]["alpha-3"].values[0])

world["Alpha3"]=alpha

fig=xp.choropleth(world.dropna(),
                   locations="Alpha3",
                   color="Cases Range",
                    projection="mercator",
                    color_discrete_sequence=["white","khaki","yellow","orange","red"])
fig.update_geos(fitbounds="locations", visible=False)
fig.update_layout(margin={"r":0,"t":0,"l":0,"b":0})
fig.show()

# Now let’s have a look at the daily cases all around the world:

count = []

for i in range(1,len(data1)):
    count.append(sum(pd.to_numeric(data1.iloc[i,1:].values)))

df = pd.DataFrame()
df["Date"] = data1["Country/Region"][1:]
df["Cases"] = count
df=df.set_index("Date") 

count = []
for i in range(1,len(data2)):
    count.append(sum(pd.to_numeric(data2.iloc[i,1:].values)))

df["Deaths"] = count

df.Cases.plot(title="Daily Covid19 Cases in World",marker=".",figsize=(5,5),label="Daily cases")
df.Cases.rolling(window=10).mean().plot(figsize=(10,5),label="MA5")
plt.ylabel("cases")
plt.legend()
plt.show()

df.Deaths.plot(title="Daily Covid19 Deaths in World",marker=".",figsize=(5,5),label="Daily deaths")
df.Deaths.rolling(window=10).mean().plot(figsize=(10,5),label="MA5")
plt.ylabel("Deaths")
plt.legend()
plt.show()
